<?php
$versions[4] = array('update_id' => 4, 4 => '1.6.0.1', "version_list" => 'v1.6.0.0', 'call' => '1600_1601', 'dbv' => 1600); //Update Info

//Update von V1.5.5.x auf V1.6.0.0
function install_1600_1601_update()
{
    return true;
}
?>