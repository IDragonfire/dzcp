<?php
$versions[5] = array('update_id' => 5, 5 => '1.6.0.3', "version_list" => 'v1.6.0.3', 'call' => '1601_1603', 'dbv' => 1603); //Update Info

//Update von V1.5.5.x auf V1.6.0.0
function install_1601_1603_update()
{
    return true;
}
?>